<div id="footer" class="card text-center">
    <div class="card-body">
        <h5 class="card-title">Exam Repository</h5>
        <p class="card-text">This Repository For Uploading The coalitiontechnologies Exam Code </p>
        <a href="<?php echo e(route('site.index')); ?>" class="btn btn-primary">Go HomePage</a>
    </div>
</div>