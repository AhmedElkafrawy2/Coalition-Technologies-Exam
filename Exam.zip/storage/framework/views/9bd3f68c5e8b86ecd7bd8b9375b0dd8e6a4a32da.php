<?php $__env->startSection("title"); ?>

    | <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <form id= "add-product-form" action="<?php echo e(route('site.store')); ?>" data-url="<?php echo e(url('/')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="product-name">Product Name</label>
                <input type="text" class="form-control" id="product-name" placeholder="Enter Product Name">
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity in stock</label>
                <input type="text" class="form-control" id="quantity" placeholder="Enter the Product Quantity">
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="text" class="form-control" id="price" placeholder="Enter the Product price">
            </div>
            <button type="submit" id="btn-form-submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <br />
    <div class="container">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Quantity</th>
                <th scope="col">Price</th>
                <th scope="col">Date</th>
                <th scope="col">Total value number</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product['name']); ?></td>
                    <td><?php echo e($product['quantity']); ?></td>
                    <td><?php echo e($product['price']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("Site.Layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>